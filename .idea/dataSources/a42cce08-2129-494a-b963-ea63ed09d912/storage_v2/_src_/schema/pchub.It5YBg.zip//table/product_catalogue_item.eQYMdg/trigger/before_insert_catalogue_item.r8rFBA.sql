create definer = root@localhost trigger before_insert_catalogue_item
    before insert
    on product_catalogue_item
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(itemID, 3)), 0) + 1 FROM product_catalogue_item);
    SET NEW.itemID = CONCAT('CI', LPAD(next_id, 6, '0'));
END;

