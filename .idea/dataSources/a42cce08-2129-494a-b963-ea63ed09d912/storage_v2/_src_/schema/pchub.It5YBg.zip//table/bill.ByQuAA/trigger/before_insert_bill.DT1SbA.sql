create definer = root@localhost trigger before_insert_bill
    before insert
    on bill
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(billID, 2)), 0) + 1 FROM bill);
    SET NEW.billID = CONCAT('B', LPAD(next_id, 6, '0'));
END;

