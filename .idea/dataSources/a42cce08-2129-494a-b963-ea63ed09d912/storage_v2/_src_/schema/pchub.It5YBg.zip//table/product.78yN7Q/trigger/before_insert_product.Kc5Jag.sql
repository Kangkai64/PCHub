create definer = root@localhost trigger before_insert_product
    before insert
    on product
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(productID, 2)), 0) + 1 FROM product);
    SET NEW.productID = CONCAT('P', LPAD(next_id, 5, '0'));
END;

