create definer = root@localhost trigger before_insert_catalogue
    before insert
    on product_catalogue
    for each row
BEGIN
    DECLARE next_id INT;
    -- Get the highest existing catalogue ID, defaulting to 0 if none exist
    SELECT IFNULL(MAX(CAST(SUBSTRING(catalogueID, 5) AS UNSIGNED)), 0) INTO next_id FROM product_catalogue;
    -- Increment the ID
    SET next_id = next_id + 1;
    -- Set the new catalogue ID
    SET NEW.catalogueID = CONCAT('CATL', LPAD(next_id, 3, '0'));
END;

