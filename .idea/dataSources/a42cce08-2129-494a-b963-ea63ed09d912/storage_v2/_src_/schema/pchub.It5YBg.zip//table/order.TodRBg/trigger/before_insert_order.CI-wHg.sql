create definer = root@localhost trigger before_insert_order
    before insert
    on `order`
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(orderID, 2)), 0) + 1 FROM `order`);
    SET NEW.orderID = CONCAT('O', LPAD(next_id, 4, '0'));
END;

