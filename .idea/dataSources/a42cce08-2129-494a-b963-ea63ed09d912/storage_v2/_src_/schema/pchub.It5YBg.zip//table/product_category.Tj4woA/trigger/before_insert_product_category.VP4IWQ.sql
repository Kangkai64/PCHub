create definer = root@localhost trigger before_insert_product_category
    before insert
    on product_category
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(categoryID, 4)), 0) + 1 FROM product_category);
    SET NEW.product_categoryID = CONCAT('CAT', LPAD(next_id, 3, '0'));
END;

