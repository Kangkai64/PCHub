create definer = root@localhost trigger before_insert_address
    before insert
    on shipping_address
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(CAST(SUBSTRING(addressID, 3) AS UNSIGNED)), 0) + 1 FROM shipping_address);
    SET NEW.shipping_addressID = CONCAT('SA', LPAD(next_id, 6, '0'));
END;

