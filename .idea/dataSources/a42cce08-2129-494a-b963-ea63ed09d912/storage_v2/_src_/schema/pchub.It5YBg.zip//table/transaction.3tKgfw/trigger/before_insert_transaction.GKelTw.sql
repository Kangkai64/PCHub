create definer = root@localhost trigger before_insert_transaction
    before insert
    on transaction
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(transactionID, 2)), 0) + 1 FROM transaction);
    SET NEW.transactionID = CONCAT('T', LPAD(next_id, 6, '0'));
END;

