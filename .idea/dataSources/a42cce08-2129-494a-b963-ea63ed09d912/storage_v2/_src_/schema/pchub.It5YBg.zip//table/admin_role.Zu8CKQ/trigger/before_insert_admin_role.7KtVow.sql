create definer = root@localhost trigger before_insert_admin_role
    before insert
    on admin_role
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(adminID, 4)), 0) + 1 FROM admin_role);
    SET NEW.adminID = CONCAT('ADM', LPAD(next_id, 3, '0'));
END;

