create definer = root@localhost trigger before_insert_cart
    before insert
    on cart
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(cartID, 3)), 0) + 1 FROM cart);
    SET NEW.cartID = CONCAT('CA', LPAD(next_id, 5, '0'));
END;

