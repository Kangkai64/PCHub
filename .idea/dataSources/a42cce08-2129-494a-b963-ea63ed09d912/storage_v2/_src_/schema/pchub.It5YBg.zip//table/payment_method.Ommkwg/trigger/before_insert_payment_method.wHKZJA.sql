create definer = root@localhost trigger before_insert_payment_method
    before insert
    on payment_method
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(payment_MethodID, 3)), 0) + 1 FROM payment_method);
    SET NEW.payment_MethodID = CONCAT('PM', LPAD(next_id, 3, '0'));
END;

