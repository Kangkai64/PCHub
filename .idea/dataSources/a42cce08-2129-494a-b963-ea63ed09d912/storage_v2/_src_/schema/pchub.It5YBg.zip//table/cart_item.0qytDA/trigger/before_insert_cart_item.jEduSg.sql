create definer = root@localhost trigger before_insert_cart_item
    before insert
    on cart_item
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(cartItemID, 3)), 0) + 1 FROM cart_item);
    SET NEW.cartItemID = CONCAT('CI', LPAD(next_id, 6, '0'));
END;

