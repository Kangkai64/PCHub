create definer = root@localhost trigger before_insert_order_item
    before insert
    on order_item
    for each row
BEGIN
    DECLARE next_id INT;
    SET next_id = (SELECT IFNULL(MAX(SUBSTRING(orderItemID, 3)), 0) + 1 FROM order_item);
    SET NEW.orderItemID = CONCAT('OI', LPAD(next_id, 7, '0'));
END;

